<?php

define("Host","localhost");
define("UN","root");
define("PW","");
define("DBname","transport");


