<?php include  "header.php";?>
<!-- page content -->

<style>

</style>
<div class="border border-secondary border-top-0" style="background-color:#2a81c9;padding-top:100px;padding-bottom:50px;">
    <div class="container text-center " style="position:relative;">
  <div class="row px-2">
      <div class="col-md">
    
      </div>

      <div class="col-md bg-light text-warning text-center rounded p-4 my-3 w-md-50 ">
    <h3 class="py-2 font-weight-bold">أسم الفورمة </h3>
    <hr class="py-1">
    <div class="input-group">
      <input type="text"  class="form-control text-right" placeholder="أكتب أكتب أكتب " aria-label="Search for...">
      <span class="input-group-btn">
      </span>
    </div>
<br>
    <div class="input-group">
      <input type="text"  class="form-control text-right" placeholder="أكتب أكتب أكتب " aria-label="Search for...">
      <span class="input-group-btn">
      </span>
    </div>
    <br>
    <button type="button" class="btn btn-success" ID="Button1">دخول</button>


</div>

      <div class="col-md">
      
      </div>
  </div>






    </div>
</div>


<script>

</script>


<?php include  "footer.php";?>